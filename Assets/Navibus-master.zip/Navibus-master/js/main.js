document.getElementById("hamburger-btn").onclick = () => {
    document.getElementById("mobile-menu").classList.remove("hidden");
  };
  document.getElementById("close-menu-btn").onclick = () => {
    document.getElementById("mobile-menu").classList.add("hidden");
  };
  