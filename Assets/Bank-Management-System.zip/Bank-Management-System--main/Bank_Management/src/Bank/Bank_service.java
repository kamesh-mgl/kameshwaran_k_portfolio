package Bank;

import java.util.HashMap;
import java.util.Map;

public class Bank_service {
	private Map<String,Account> acc;
	
	public Bank_service() {
		this.acc=new HashMap<>();
	}
	
	public void addAccount(String accountnumber,String customername, double balance) {
		if(acc.containsKey(accountnumber)) {
			System.out.println("--Account Already Exists. Use Different Account Number--");
		}
		else {
			Account account=new Account(accountnumber,customername,balance);
			acc.put(accountnumber, account);
			System.out.println("--Account Created Successfully--");
		}

	}
	
	public void deposit(String accountnumber,double amount) {
		if(amount>0) {
			if(acc.containsKey(accountnumber)) {
				Account account=acc.get(accountnumber);
				account.deposit(amount);
				System.out.println("--Deposit Successfull--");
			}
			else {
				System.out.println("--Invalid Account Number--");
			}
		}
		else {
			System.out.println("Amount Should Be Greater Than 0");
		}
	}
	
	public void withdraw(String accountnumber,double amount) {
		if(amount>0) {
			if(acc.containsKey(accountnumber)) {
				Account account=acc.get(accountnumber);
				if(amount>0 && amount<=account.getAccountbalance()) {
					account.withdraw(amount);
					System.out.println("--Withdraw Successful--");
				}
				else {
					System.out.println("--Account Balance is 0 or Account balacne is lower the enterd value--");
				}
			}
			else {
				System.out.println("--Invalid Account Number--");
			}
		}
		else {
			System.out.println("Amount Should Be Greater Than 0");
		}
	}
	
	public void transfer(String fromaccount,String toaccount,double amount) {
		if(amount>0) {
			if(acc.containsKey(fromaccount)&& acc.containsKey(toaccount)) {
				Account account1=acc.get(fromaccount);
				Account account2=acc.get(toaccount);
				if(amount<=account1.getAccountbalance()) {
					account1.withdraw(amount);
					account2.deposit(amount);
					System.out.println("--Rs. "+amount+" Transferred From "+fromaccount+" to "+toaccount+" Successfully--");
				}
				else {
					System.out.println("--Insufficient Amount--");
				}
			}
			else {
				System.out.println("--Invalid Account Number");
			}
		}
		else {
			System.out.println("Amount Should Be Greater than 0");
		}
	}
	
	public void display(String accountnumber) {
		if(acc.containsKey(accountnumber)) {
			Account account=acc.get(accountnumber);
			System.out.println("Account Number:"+account.getAccountnumber());
			System.out.println("Account Holder Name:"+account.getCustomername());
			System.out.println("Account balance:"+account.getAccountbalance());
		}
		else {
			System.out.println("--Invalid Account Number--");
		}
	}
}
