package Bank;

import java.util.Scanner;

public class Bank_driver {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Bank_service service = new Bank_service();
        boolean flag = true;
        while (flag) {
            System.out.println(" Welcome To The Bank");
            System.out.println("Press 1 to Add Account");
            System.out.println("Press 2 to Deposit Amount");
            System.out.println("Press 3 to Withdraw Amount");
            System.out.println("Press 4 to Transfer Amount From Account to Account");
            System.out.println("Press 5 to Display Account Details");
            System.out.println("Press 6 to Exit");
            System.out.print("Enter Option: ");
            
            int option = scan.nextInt();
            switch (option) {
                case 1:
                    System.out.print("Enter Account Number: ");
                    String acc_num = scan.next();
                    System.out.print("Enter Customer Name: ");
                    String customer_name = scan.next();
                    System.out.print("Enter Initial Amount: ");
                    double amount = scan.nextDouble();
                    service.addAccount(acc_num, customer_name, amount);
                    break;

                case 2:
                    System.out.print("Enter Account Number: ");
                    acc_num = scan.next();
                    System.out.print("Enter Deposit Amount: ");
                    amount = scan.nextDouble();
                    service.deposit(acc_num, amount);
                    break;
                    
                case 3:
                    System.out.print("Enter Account Number: ");
                    acc_num = scan.next();
                    System.out.print("Enter Amount to Withdraw: ");
                    amount = scan.nextDouble();
                    service.withdraw(acc_num, amount);
                    break;
                    
                case 4:
                	System.out.println("Enter Sender  Account Number: ");
                	acc_num=scan.next();
                	System.out.println("Enter Receiver Account Number: ");
                	String acc_num2=scan.next();
                	System.out.println("Enter Amount To Be Transferred: ");
                	amount=scan.nextDouble();
                	service.transfer(acc_num, acc_num2, amount);
                	break;
                	

                case 5:
                    System.out.print("Enter Account Number: "); 
                    acc_num = scan.next();
                    service.display(acc_num);
                    break;

                case 6:
                    flag = false;
                    System.out.println("Thank you for using the Bank");
                    break;

                default:
                    System.out.println("Enter a valid option");
            }
        }
        scan.close();
    }
}
