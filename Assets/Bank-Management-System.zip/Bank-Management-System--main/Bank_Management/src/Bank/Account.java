package Bank;

public class Account {
	private String accountnumber;
	private String customername;
	private double accountbalance;
	
	public Account(String accountnumber, String customername, double accountbalance) {
		this.accountnumber = accountnumber;
		this.customername = customername;
		this.accountbalance = accountbalance;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public String getCustomername() {
		return customername;
	}

	public double getAccountbalance() {
		return accountbalance;
	}
	
	public void deposit(double amount) {
		accountbalance+=amount;
	}
	
	public void withdraw(double amount) {
		accountbalance-=amount;
	}



	
	
	
	
	

}
